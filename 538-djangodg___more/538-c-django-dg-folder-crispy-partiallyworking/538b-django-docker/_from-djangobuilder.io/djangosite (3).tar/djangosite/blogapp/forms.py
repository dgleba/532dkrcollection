from django import forms
from . import models


class BookForm(forms.ModelForm):
    class Meta:
        model = models.Book
        fields = [
            "name",
            "author",
        ]


class PostForm(forms.ModelForm):
    class Meta:
        model = models.Post
        fields = [
            "body",
            "title",
            "Book",
        ]
